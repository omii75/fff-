"use client"

import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"

const data = [
  { month: "Jan", income: 45000, expenses: 32000 },
  { month: "Feb", income: 52000, expenses: 28000 },
  { month: "Mar", income: 48000, expenses: 35000 },
  { month: "Apr", income: 61000, expenses: 42000 },
  { month: "May", income: 55000, expenses: 38000 },
  { month: "Jun", income: 67000, expenses: 45000 },
]

export function IncomeExpenseChart() {
  return (
    <div className="h-80">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
          <XAxis dataKey="month" tick={{ fontSize: 12 }} stroke="#666" />
          <YAxis tick={{ fontSize: 12 }} stroke="#666" tickFormatter={(value) => `₹${(value / 1000).toFixed(0)}k`} />
          <Tooltip
            formatter={(value: number) => [`₹${value.toLocaleString()}`, ""]}
            labelStyle={{ color: "#333" }}
            contentStyle={{
              backgroundColor: "white",
              border: "1px solid #ccc",
              borderRadius: "8px",
            }}
          />
          <Bar dataKey="income" fill="#16a34a" name="Income" radius={[4, 4, 0, 0]} />
          <Bar dataKey="expenses" fill="#d97706" name="Expenses" radius={[4, 4, 0, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  )
}
