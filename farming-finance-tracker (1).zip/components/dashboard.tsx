"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  PlusCircle,
  TrendingUp,
  TrendingDown,
  Wallet,
  BarChart3,
  PieChart,
  Calendar,
  Wifi,
  WifiOff,
  List,
  MapPin,
  Settings,
} from "lucide-react"
import { IncomeExpenseChart } from "@/components/income-expense-chart"
import { CategoryBreakdown } from "@/components/category-breakdown"
import Link from "next/link"
import { useLanguage } from "@/contexts/language-context"
import { LanguageSelector } from "@/components/language-selector"
import { storage, type Transaction } from "@/lib/storage"

export function Dashboard() {
  const { t } = useLanguage()
  const isOnline = true // This would be dynamic in a real app
  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [totals, setTotals] = useState({
    totalIncome: 0,
    totalExpenses: 0,
    netBalance: 0,
  })

  useEffect(() => {
    const loadData = () => {
      const storedTransactions = storage.getTransactions()
      setTransactions(storedTransactions)

      // Calculate real totals
      const income = storedTransactions.filter((t) => t.type === "income").reduce((sum, t) => sum + t.amount, 0)

      const expenses = storedTransactions.filter((t) => t.type === "expense").reduce((sum, t) => sum + t.amount, 0)

      setTotals({
        totalIncome: income,
        totalExpenses: expenses,
        netBalance: income - expenses,
      })
    }

    loadData()
  }, [])

  const recentTransactions = transactions
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 3)

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-amber-50">
      {/* Header */}
      <header className="bg-white border-b border-green-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-green-600 rounded-lg flex items-center justify-center">
                <BarChart3 className="w-5 h-5 text-white" />
              </div>
              <h1 className="text-xl font-bold text-green-800">{t("dashboard.title")}</h1>
            </div>

            <div className="flex items-center space-x-3">
              <LanguageSelector />
              <Link href="/add-transaction">
                <Button variant="outline" size="sm" className="flex items-center space-x-2 bg-transparent">
                  <PlusCircle className="w-4 h-4" />
                  <span className="hidden sm:inline">Add</span>
                </Button>
              </Link>
              <Link href="/transactions">
                <Button variant="outline" size="sm" className="flex items-center space-x-2 bg-transparent">
                  <List className="w-4 h-4" />
                  <span className="hidden sm:inline">{t("transactions.title")}</span>
                </Button>
              </Link>
              <Link href="/farms">
                <Button variant="outline" size="sm" className="flex items-center space-x-2 bg-transparent">
                  <MapPin className="w-4 h-4" />
                  <span className="hidden sm:inline">{t("nav.farms")}</span>
                </Button>
              </Link>
              <Link href="/reports">
                <Button variant="outline" size="sm" className="flex items-center space-x-2 bg-transparent">
                  <BarChart3 className="w-4 h-4" />
                  <span className="hidden sm:inline">{t("nav.reports")}</span>
                </Button>
              </Link>
              <Link href="/settings">
                <Button variant="outline" size="sm" className="flex items-center space-x-2 bg-transparent">
                  <Settings className="w-4 h-4" />
                  <span className="hidden sm:inline">{t("nav.settings")}</span>
                </Button>
              </Link>
              <Badge variant={isOnline ? "default" : "destructive"} className="flex items-center space-x-1">
                {isOnline ? <Wifi className="w-3 h-3" /> : <WifiOff className="w-3 h-3" />}
                <span>{isOnline ? t("dashboard.online") : t("dashboard.offline")}</span>
              </Badge>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Quick Actions */}
        <div className="mb-8">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Link href="/add-transaction">
              <Button size="lg" className="h-16 bg-green-600 hover:bg-green-700 text-white w-full">
                <PlusCircle className="w-6 h-6 mr-3" />
                <span className="text-lg font-semibold">{t("dashboard.addIncome")}</span>
              </Button>
            </Link>
            <Link href="/add-transaction">
              <Button
                size="lg"
                variant="outline"
                className="h-16 border-2 border-amber-600 text-amber-700 hover:bg-amber-50 bg-transparent w-full"
              >
                <PlusCircle className="w-6 h-6 mr-3" />
                <span className="text-lg font-semibold">{t("dashboard.addExpense")}</span>
              </Button>
            </Link>
          </div>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="border-green-200 bg-white shadow-md">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-green-700">{t("dashboard.totalIncome")}</CardTitle>
              <TrendingUp className="h-5 w-5 text-green-600" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-green-800">
                {t("common.currency")}
                {totals.totalIncome.toLocaleString()}
              </div>
              <p className="text-xs text-green-600 mt-1">
                {transactions.filter((t) => t.type === "income").length} income transactions
              </p>
            </CardContent>
          </Card>

          <Card className="border-amber-200 bg-white shadow-md">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-amber-700">{t("dashboard.totalExpenses")}</CardTitle>
              <TrendingDown className="h-5 w-5 text-amber-600" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-amber-800">
                {t("common.currency")}
                {totals.totalExpenses.toLocaleString()}
              </div>
              <p className="text-xs text-amber-600 mt-1">
                {transactions.filter((t) => t.type === "expense").length} expense transactions
              </p>
            </CardContent>
          </Card>

          <Card className="border-blue-200 bg-white shadow-md">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-blue-700">{t("dashboard.netProfit")}</CardTitle>
              <Wallet className="h-5 w-5 text-blue-600" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-blue-800">
                {t("common.currency")}
                {totals.netBalance.toLocaleString()}
              </div>
              <p className="text-xs text-blue-600 mt-1">{transactions.length} total transactions</p>
            </CardContent>
          </Card>
        </div>

        {/* Charts Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          <Card className="bg-white shadow-md">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <BarChart3 className="w-5 h-5 text-green-600" />
                <span>{t("dashboard.incomeVsExpenses")}</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <IncomeExpenseChart />
            </CardContent>
          </Card>

          <Card className="bg-white shadow-md">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <PieChart className="w-5 h-5 text-amber-600" />
                <span>{t("dashboard.categoryBreakdown")}</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <CategoryBreakdown />
            </CardContent>
          </Card>
        </div>

        {/* Recent Transactions */}
        <Card className="bg-white shadow-md">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="flex items-center space-x-2">
              <Calendar className="w-5 h-5 text-gray-600" />
              <span>{t("dashboard.recentTransactions")}</span>
            </CardTitle>
            <Link href="/transactions">
              <Button variant="outline" size="sm">
                {t("dashboard.viewAll")}
              </Button>
            </Link>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentTransactions.length === 0 ? (
                <div className="text-center py-8">
                  <p className="text-gray-500 mb-4">No transactions yet</p>
                  <Link href="/add-transaction">
                    <Button className="bg-green-600 hover:bg-green-700">
                      <PlusCircle className="w-4 h-4 mr-2" />
                      Add Your First Transaction
                    </Button>
                  </Link>
                </div>
              ) : (
                recentTransactions.map((transaction) => (
                  <div
                    key={transaction.id}
                    className="flex items-center justify-between p-4 border border-gray-100 rounded-lg"
                  >
                    <div className="flex items-center space-x-4">
                      <div
                        className={`w-3 h-3 rounded-full ${
                          transaction.type === "income" ? "bg-green-500" : "bg-amber-500"
                        }`}
                      />
                      <div>
                        <p className="font-medium text-gray-900">{transaction.category}</p>
                        <p className="text-sm text-gray-500">
                          {transaction.plot} • {new Date(transaction.date).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                    <div className={`font-bold ${transaction.type === "income" ? "text-green-600" : "text-amber-600"}`}>
                      {transaction.type === "income" ? "+" : "-"}
                      {t("common.currency")}
                      {transaction.amount.toLocaleString()}
                    </div>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
