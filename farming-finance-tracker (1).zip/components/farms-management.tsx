"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Plus, MapPin, TrendingUp, TrendingDown, BarChart3 } from "lucide-react"
import Link from "next/link"
import { useLanguage } from "@/contexts/language-context"

const mockFarms = [
  {
    id: 1,
    name: "Field A - Wheat Farm",
    area: "5.2 acres",
    crop: "Wheat",
    totalIncome: 45000,
    totalExpenses: 28000,
    netProfit: 17000,
    lastActivity: "2024-01-20",
    status: "Active",
  },
  {
    id: 2,
    name: "Field B - Corn Farm",
    area: "3.8 acres",
    crop: "Corn",
    totalIncome: 32000,
    totalExpenses: 22000,
    netProfit: 10000,
    lastActivity: "2024-01-19",
    status: "Active",
  },
  {
    id: 3,
    name: "Field C - Rice Farm",
    area: "4.5 acres",
    crop: "Rice",
    totalIncome: 38000,
    totalExpenses: 25000,
    netProfit: 13000,
    lastActivity: "2024-01-18",
    status: "Harvested",
  },
]

export function FarmsManagement() {
  const { t } = useLanguage()

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-amber-50">
      {/* Header */}
      <header className="bg-white border-b border-green-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <Link href="/">
                <Button variant="ghost" size="sm" className="text-green-700 hover:text-green-800">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  {t("nav.dashboard")}
                </Button>
              </Link>
              <h1 className="text-xl font-bold text-green-800">{t("nav.farms")} Management</h1>
            </div>

            <Button className="bg-green-600 hover:bg-green-700 text-white">
              <Plus className="w-4 h-4 mr-2" />
              Add Farm/Plot
            </Button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="border-green-200 bg-white shadow-md">
            <CardContent className="p-6">
              <div className="text-center">
                <p className="text-sm font-medium text-green-700">Total Farms</p>
                <p className="text-3xl font-bold text-green-800">{mockFarms.length}</p>
              </div>
            </CardContent>
          </Card>

          <Card className="border-blue-200 bg-white shadow-md">
            <CardContent className="p-6">
              <div className="text-center">
                <p className="text-sm font-medium text-blue-700">Total Area</p>
                <p className="text-3xl font-bold text-blue-800">13.5</p>
                <p className="text-xs text-blue-600">acres</p>
              </div>
            </CardContent>
          </Card>

          <Card className="border-green-200 bg-white shadow-md">
            <CardContent className="p-6">
              <div className="text-center">
                <p className="text-sm font-medium text-green-700">Total Income</p>
                <p className="text-2xl font-bold text-green-800">
                  {t("common.currency")}
                  {mockFarms.reduce((sum, farm) => sum + farm.totalIncome, 0).toLocaleString()}
                </p>
              </div>
            </CardContent>
          </Card>

          <Card className="border-amber-200 bg-white shadow-md">
            <CardContent className="p-6">
              <div className="text-center">
                <p className="text-sm font-medium text-amber-700">Total Expenses</p>
                <p className="text-2xl font-bold text-amber-800">
                  {t("common.currency")}
                  {mockFarms.reduce((sum, farm) => sum + farm.totalExpenses, 0).toLocaleString()}
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Farms Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {mockFarms.map((farm) => (
            <Card key={farm.id} className="bg-white shadow-md hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-lg text-green-800">{farm.name}</CardTitle>
                    <div className="flex items-center space-x-2 mt-2">
                      <MapPin className="w-4 h-4 text-gray-500" />
                      <span className="text-sm text-gray-600">{farm.area}</span>
                      <Badge variant="outline" className="text-xs">
                        {farm.crop}
                      </Badge>
                    </div>
                  </div>
                  <Badge variant={farm.status === "Active" ? "default" : "secondary"} className="text-xs">
                    {farm.status}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {/* Financial Summary */}
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center p-3 bg-green-50 rounded-lg">
                      <div className="flex items-center justify-center space-x-1 mb-1">
                        <TrendingUp className="w-4 h-4 text-green-600" />
                        <span className="text-xs font-medium text-green-700">Income</span>
                      </div>
                      <p className="text-lg font-bold text-green-800">
                        {t("common.currency")}
                        {farm.totalIncome.toLocaleString()}
                      </p>
                    </div>
                    <div className="text-center p-3 bg-amber-50 rounded-lg">
                      <div className="flex items-center justify-center space-x-1 mb-1">
                        <TrendingDown className="w-4 h-4 text-amber-600" />
                        <span className="text-xs font-medium text-amber-700">Expenses</span>
                      </div>
                      <p className="text-lg font-bold text-amber-800">
                        {t("common.currency")}
                        {farm.totalExpenses.toLocaleString()}
                      </p>
                    </div>
                  </div>

                  {/* Net Profit */}
                  <div className="text-center p-3 bg-blue-50 rounded-lg">
                    <div className="flex items-center justify-center space-x-1 mb-1">
                      <BarChart3 className="w-4 h-4 text-blue-600" />
                      <span className="text-xs font-medium text-blue-700">Net Profit</span>
                    </div>
                    <p className="text-xl font-bold text-blue-800">
                      {t("common.currency")}
                      {farm.netProfit.toLocaleString()}
                    </p>
                  </div>

                  {/* Last Activity */}
                  <div className="text-center">
                    <p className="text-xs text-gray-500">Last Activity: {farm.lastActivity}</p>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex space-x-2">
                    <Button variant="outline" size="sm" className="flex-1 bg-transparent">
                      View Details
                    </Button>
                    <Button variant="outline" size="sm" className="flex-1 bg-transparent">
                      {t("common.edit")}
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </main>
    </div>
  )
}
