"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ArrowLeft, Download, TrendingUp, TrendingDown, BarChart3 } from "lucide-react"
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts"
import Link from "next/link"
import { useLanguage } from "@/contexts/language-context"

const monthlyData = [
  { month: "Jan", income: 45000, expenses: 32000, profit: 13000 },
  { month: "Feb", income: 52000, expenses: 28000, profit: 24000 },
  { month: "Mar", income: 48000, expenses: 35000, profit: 13000 },
  { month: "Apr", income: 61000, expenses: 42000, profit: 19000 },
  { month: "May", income: 55000, expenses: 38000, profit: 17000 },
  { month: "Jun", income: 67000, expenses: 45000, profit: 22000 },
]

const categoryData = [
  { name: "Seeds", value: 25000, color: "#8b5cf6" },
  { name: "Fertilizer", value: 18000, color: "#06b6d4" },
  { name: "Equipment", value: 15000, color: "#f59e0b" },
  { name: "Labor", value: 20000, color: "#ef4444" },
  { name: "Utilities", value: 9500, color: "#10b981" },
]

export function ReportsInsights() {
  const { t } = useLanguage()
  const [timePeriod, setTimePeriod] = useState("monthly")

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-amber-50">
      {/* Header */}
      <header className="bg-white border-b border-green-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <Link href="/">
                <Button variant="ghost" size="sm" className="text-green-700 hover:text-green-800">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  {t("nav.dashboard")}
                </Button>
              </Link>
              <h1 className="text-xl font-bold text-green-800">{t("nav.reports")} & Insights</h1>
            </div>

            <div className="flex items-center space-x-3">
              <Select value={timePeriod} onValueChange={setTimePeriod}>
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="daily">Daily</SelectItem>
                  <SelectItem value="weekly">Weekly</SelectItem>
                  <SelectItem value="monthly">Monthly</SelectItem>
                  <SelectItem value="seasonal">Seasonal</SelectItem>
                </SelectContent>
              </Select>
              <Button variant="outline" size="sm">
                <Download className="w-4 h-4 mr-2" />
                Export
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="border-green-200 bg-white shadow-md">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-green-700">Avg Monthly Income</p>
                  <p className="text-2xl font-bold text-green-800">
                    {t("common.currency")}
                    {(monthlyData.reduce((sum, item) => sum + item.income, 0) / monthlyData.length).toLocaleString()}
                  </p>
                  <p className="text-xs text-green-600">+12% vs last period</p>
                </div>
                <TrendingUp className="h-8 w-8 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-amber-200 bg-white shadow-md">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-amber-700">Avg Monthly Expenses</p>
                  <p className="text-2xl font-bold text-amber-800">
                    {t("common.currency")}
                    {(monthlyData.reduce((sum, item) => sum + item.expenses, 0) / monthlyData.length).toLocaleString()}
                  </p>
                  <p className="text-xs text-amber-600">+5% vs last period</p>
                </div>
                <TrendingDown className="h-8 w-8 text-amber-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-blue-200 bg-white shadow-md">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-blue-700">Avg Monthly Profit</p>
                  <p className="text-2xl font-bold text-blue-800">
                    {t("common.currency")}
                    {(monthlyData.reduce((sum, item) => sum + item.profit, 0) / monthlyData.length).toLocaleString()}
                  </p>
                  <p className="text-xs text-blue-600">+18% vs last period</p>
                </div>
                <BarChart3 className="h-8 w-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-purple-200 bg-white shadow-md">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-purple-700">Profit Margin</p>
                  <p className="text-2xl font-bold text-purple-800">32%</p>
                  <p className="text-xs text-purple-600">+3% vs last period</p>
                </div>
                <div className="h-8 w-8 rounded-full bg-purple-100 flex items-center justify-center">
                  <span className="text-purple-600 font-bold">%</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Charts Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          {/* Profit Trend Chart */}
          <Card className="bg-white shadow-md">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <TrendingUp className="w-5 h-5 text-green-600" />
                <span>Profit Trend Analysis</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={monthlyData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                    <XAxis dataKey="month" tick={{ fontSize: 12 }} stroke="#666" />
                    <YAxis
                      tick={{ fontSize: 12 }}
                      stroke="#666"
                      tickFormatter={(value) => `₹${(value / 1000).toFixed(0)}k`}
                    />
                    <Tooltip
                      formatter={(value: number) => [`₹${value.toLocaleString()}`, ""]}
                      labelStyle={{ color: "#333" }}
                      contentStyle={{
                        backgroundColor: "white",
                        border: "1px solid #ccc",
                        borderRadius: "8px",
                      }}
                    />
                    <Area
                      type="monotone"
                      dataKey="profit"
                      stroke="#16a34a"
                      fill="#16a34a"
                      fillOpacity={0.3}
                      strokeWidth={2}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          {/* Expense Breakdown */}
          <Card className="bg-white shadow-md">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <BarChart3 className="w-5 h-5 text-amber-600" />
                <span>Expense Category Breakdown</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={categoryData}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={100}
                      paddingAngle={5}
                      dataKey="value"
                    >
                      {categoryData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip
                      formatter={(value: number) => [`₹${value.toLocaleString()}`, "Amount"]}
                      contentStyle={{
                        backgroundColor: "white",
                        border: "1px solid #ccc",
                        borderRadius: "8px",
                      }}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Insights Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card className="bg-white shadow-md">
            <CardHeader>
              <CardTitle className="text-green-800">Key Insights</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-green-500 rounded-full mt-2"></div>
                  <div>
                    <p className="font-medium text-gray-900">Best Performing Month</p>
                    <p className="text-sm text-gray-600">June showed highest profit margin at 33%</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-amber-500 rounded-full mt-2"></div>
                  <div>
                    <p className="font-medium text-gray-900">Cost Optimization</p>
                    <p className="text-sm text-gray-600">
                      Labor costs increased by 15% - consider efficiency improvements
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
                  <div>
                    <p className="font-medium text-gray-900">Revenue Growth</p>
                    <p className="text-sm text-gray-600">Consistent 12% month-over-month income growth</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white shadow-md">
            <CardHeader>
              <CardTitle className="text-blue-800">Recommendations</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-green-500 rounded-full mt-2"></div>
                  <div>
                    <p className="font-medium text-gray-900">Seasonal Planning</p>
                    <p className="text-sm text-gray-600">Plan for higher fertilizer costs in upcoming season</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-amber-500 rounded-full mt-2"></div>
                  <div>
                    <p className="font-medium text-gray-900">Equipment Investment</p>
                    <p className="text-sm text-gray-600">Consider bulk purchasing to reduce per-unit costs</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
                  <div>
                    <p className="font-medium text-gray-900">Diversification</p>
                    <p className="text-sm text-gray-600">Explore additional revenue streams to reduce risk</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
