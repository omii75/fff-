"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Wifi, WifiOff, RefreshCw, User, Bell, Shield, Download } from "lucide-react"
import Link from "next/link"
import { useLanguage } from "@/contexts/language-context"
import { LanguageSelector } from "@/components/language-selector"

export function SettingsSync() {
  const { t } = useLanguage()
  const [isOnline, setIsOnline] = useState(true)
  const [autoSync, setAutoSync] = useState(true)
  const [voiceInput, setVoiceInput] = useState(true)
  const [notifications, setNotifications] = useState(true)
  const [highContrast, setHighContrast] = useState(false)
  const [lastSync, setLastSync] = useState("2024-01-20 14:30")

  const handleManualSync = () => {
    // Simulate sync process
    setLastSync(new Date().toLocaleString())
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-amber-50">
      {/* Header */}
      <header className="bg-white border-b border-green-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <Link href="/">
                <Button variant="ghost" size="sm" className="text-green-700 hover:text-green-800">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  {t("nav.dashboard")}
                </Button>
              </Link>
              <h1 className="text-xl font-bold text-green-800">{t("nav.settings")}</h1>
            </div>

            <Badge variant={isOnline ? "default" : "destructive"} className="flex items-center space-x-1">
              {isOnline ? <Wifi className="w-3 h-3" /> : <WifiOff className="w-3 h-3" />}
              <span>{isOnline ? t("dashboard.online") : t("dashboard.offline")}</span>
            </Badge>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Language & Accessibility */}
          <Card className="bg-white shadow-md">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <User className="w-5 h-5 text-green-600" />
                <span>Language & Accessibility</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label className="text-sm font-medium">Language Selection</Label>
                <LanguageSelector />
                <p className="text-xs text-gray-500">Choose your preferred language for the app interface</p>
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <Label htmlFor="voice-input" className="text-sm font-medium">
                    Voice Input
                  </Label>
                  <p className="text-xs text-gray-500">Enable voice input for transaction notes</p>
                </div>
                <Switch id="voice-input" checked={voiceInput} onCheckedChange={setVoiceInput} />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <Label htmlFor="high-contrast" className="text-sm font-medium">
                    High Contrast Mode
                  </Label>
                  <p className="text-xs text-gray-500">Improve visibility for outdoor use</p>
                </div>
                <Switch id="high-contrast" checked={highContrast} onCheckedChange={setHighContrast} />
              </div>
            </CardContent>
          </Card>

          {/* Sync Settings */}
          <Card className="bg-white shadow-md">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <RefreshCw className="w-5 h-5 text-blue-600" />
                <span>Data Sync</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <Label htmlFor="auto-sync" className="text-sm font-medium">
                    Automatic Sync
                  </Label>
                  <p className="text-xs text-gray-500">Sync data when internet is available</p>
                </div>
                <Switch id="auto-sync" checked={autoSync} onCheckedChange={setAutoSync} />
              </div>

              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Last Sync</span>
                  <span className="text-sm text-gray-600">{lastSync}</span>
                </div>
                <Button
                  onClick={handleManualSync}
                  className="w-full bg-blue-600 hover:bg-blue-700"
                  disabled={!isOnline}
                >
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Sync Now
                </Button>
                {!isOnline && <p className="text-xs text-amber-600">Sync unavailable - device is offline</p>}
              </div>

              <div className="p-3 bg-green-50 rounded-lg">
                <p className="text-sm text-green-800 font-medium">Offline Mode Active</p>
                <p className="text-xs text-green-600">All data is saved locally and will sync when online</p>
              </div>
            </CardContent>
          </Card>

          {/* Notifications */}
          <Card className="bg-white shadow-md">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Bell className="w-5 h-5 text-amber-600" />
                <span>Notifications</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <Label htmlFor="notifications" className="text-sm font-medium">
                    Push Notifications
                  </Label>
                  <p className="text-xs text-gray-500">Get notified about important updates</p>
                </div>
                <Switch id="notifications" checked={notifications} onCheckedChange={setNotifications} />
              </div>

              <div className="space-y-3">
                <Label className="text-sm font-medium">Notification Types</Label>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Sync Status</span>
                    <Switch defaultChecked />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Daily Summaries</span>
                    <Switch defaultChecked />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Expense Alerts</span>
                    <Switch />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Data & Privacy */}
          <Card className="bg-white shadow-md">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Shield className="w-5 h-5 text-purple-600" />
                <span>Data & Privacy</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-3">
                <Button variant="outline" className="w-full justify-start bg-transparent">
                  <Download className="w-4 h-4 mr-2" />
                  Export All Data
                </Button>
                <Button variant="outline" className="w-full justify-start bg-transparent">
                  <Shield className="w-4 h-4 mr-2" />
                  Privacy Settings
                </Button>
              </div>

              <div className="p-3 bg-blue-50 rounded-lg">
                <p className="text-sm text-blue-800 font-medium">Data Security</p>
                <p className="text-xs text-blue-600">All data is encrypted and stored securely on your device</p>
              </div>

              <div className="space-y-2">
                <Label className="text-sm font-medium">Storage Usage</Label>
                <div className="flex items-center justify-between text-sm">
                  <span>Local Database</span>
                  <span className="text-gray-600">2.4 MB</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span>Images & Files</span>
                  <span className="text-gray-600">1.2 MB</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* App Information */}
        <Card className="bg-white shadow-md mt-6">
          <CardHeader>
            <CardTitle>App Information</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="text-center">
                <p className="text-sm font-medium text-gray-700">Version</p>
                <p className="text-lg font-bold text-green-800">1.0.0</p>
              </div>
              <div className="text-center">
                <p className="text-sm font-medium text-gray-700">Last Updated</p>
                <p className="text-lg font-bold text-blue-800">Jan 2024</p>
              </div>
              <div className="text-center">
                <p className="text-sm font-medium text-gray-700">Developer</p>
                <p className="text-lg font-bold text-purple-800">Farm Tech</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
