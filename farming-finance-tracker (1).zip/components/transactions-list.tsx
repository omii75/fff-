"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ArrowLeft, Search, Filter, Plus, TrendingUp, TrendingDown, Calendar, MapPin, Trash2 } from "lucide-react"
import Link from "next/link"
import { useLanguage } from "@/contexts/language-context"
import { storage, type Transaction } from "@/lib/storage"

const categoryColors = {
  "Crop Sale": "bg-green-100 text-green-800 border-green-200",
  Livestock: "bg-blue-100 text-blue-800 border-blue-200",
  Seeds: "bg-purple-100 text-purple-800 border-purple-200",
  Fertilizer: "bg-orange-100 text-orange-800 border-orange-200",
  Equipment: "bg-red-100 text-red-800 border-red-200",
  Labor: "bg-yellow-100 text-yellow-800 border-yellow-200",
  Utilities: "bg-cyan-100 text-cyan-800 border-cyan-200",
  "Government Subsidy": "bg-indigo-100 text-indigo-800 border-indigo-200",
  Transportation: "bg-pink-100 text-pink-800 border-pink-200",
  "Other Income": "bg-teal-100 text-teal-800 border-teal-200",
  "Other Expense": "bg-gray-100 text-gray-800 border-gray-200",
}

export function TransactionsList() {
  const { t } = useLanguage()
  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [filterType, setFilterType] = useState("all")
  const [filterCategory, setFilterCategory] = useState("all")
  const [filterPlot, setFilterPlot] = useState("all")

  useEffect(() => {
    const loadTransactions = () => {
      const storedTransactions = storage.getTransactions()
      setTransactions(storedTransactions)
    }

    loadTransactions()
  }, [])

  const categories = [...new Set(transactions.map((t) => t.category))]
  const plots = [...new Set(transactions.map((t) => t.plot))]

  // Filter transactions based on search and filters
  const filteredTransactions = transactions.filter((transaction) => {
    const matchesSearch =
      transaction.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (transaction.subcategory && transaction.subcategory.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (transaction.notes && transaction.notes.toLowerCase().includes(searchTerm.toLowerCase()))

    const matchesType = filterType === "all" || transaction.type === filterType
    const matchesCategory = filterCategory === "all" || transaction.category === filterCategory
    const matchesPlot = filterPlot === "all" || transaction.plot === filterPlot

    return matchesSearch && matchesType && matchesCategory && matchesPlot
  })

  // Calculate totals for filtered transactions
  const totalIncome = filteredTransactions.filter((t) => t.type === "income").reduce((sum, t) => sum + t.amount, 0)
  const totalExpenses = filteredTransactions.filter((t) => t.type === "expense").reduce((sum, t) => sum + t.amount, 0)

  const handleDeleteTransaction = (id: string) => {
    const transaction = transactions.find((t) => t.id === id)
    if (!transaction) return

    const confirmMessage = `Are you sure you want to delete this ${transaction.type} of ${t("common.currency")}${transaction.amount.toLocaleString()} for ${transaction.category}?`

    if (confirm(confirmMessage)) {
      try {
        const success = storage.deleteTransaction(id)
        if (success) {
          setTransactions((prevTransactions) => prevTransactions.filter((t) => t.id !== id))
          alert("Transaction deleted successfully!")
        } else {
          alert("Failed to delete transaction. Transaction not found.")
        }
      } catch (error) {
        console.error("Error deleting transaction:", error)
        alert("Failed to delete transaction. Please try again.")
      }
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-amber-50">
      {/* Header */}
      <header className="bg-white border-b border-green-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <Link href="/">
                <Button variant="ghost" size="sm" className="text-green-700 hover:text-green-800">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  {t("nav.dashboard")}
                </Button>
              </Link>
              <h1 className="text-xl font-bold text-green-800">{t("transactions.title")}</h1>
            </div>

            <Link href="/add-transaction">
              <Button className="bg-green-600 hover:bg-green-700 text-white">
                <Plus className="w-4 h-4 mr-2" />
                {t("common.add")} Transaction
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="border-green-200 bg-white shadow-md">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-green-700">{t("transactions.filterIncome")}</p>
                  <p className="text-2xl font-bold text-green-800">
                    {t("common.currency")}
                    {totalIncome.toLocaleString()}
                  </p>
                </div>
                <TrendingUp className="h-8 w-8 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-amber-200 bg-white shadow-md">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-amber-700">{t("transactions.filterExpense")}</p>
                  <p className="text-2xl font-bold text-amber-800">
                    {t("common.currency")}
                    {totalExpenses.toLocaleString()}
                  </p>
                </div>
                <TrendingDown className="h-8 w-8 text-amber-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-blue-200 bg-white shadow-md">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-blue-700">{t("dashboard.netProfit")}</p>
                  <p className="text-2xl font-bold text-blue-800">
                    {t("common.currency")}
                    {(totalIncome - totalExpenses).toLocaleString()}
                  </p>
                </div>
                <div className="text-blue-600">
                  {totalIncome - totalExpenses >= 0 ? (
                    <TrendingUp className="h-8 w-8" />
                  ) : (
                    <TrendingDown className="h-8 w-8" />
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Search and Filters */}
        <Card className="bg-white shadow-md mb-6">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Filter className="w-5 h-5 text-gray-600" />
              <span>
                {t("common.search")} & {t("common.filter")}
              </span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder={t("transactions.search")}
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>

              <Select value={filterType} onValueChange={setFilterType}>
                <SelectTrigger>
                  <SelectValue placeholder={t("transactions.type")} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">{t("transactions.filterAll")}</SelectItem>
                  <SelectItem value="income">{t("transactions.filterIncome")}</SelectItem>
                  <SelectItem value="expense">{t("transactions.filterExpense")}</SelectItem>
                </SelectContent>
              </Select>

              <Select value={filterCategory} onValueChange={setFilterCategory}>
                <SelectTrigger>
                  <SelectValue placeholder={t("transactions.category")} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">
                    {t("transactions.filterAll")} {t("transactions.category")}
                  </SelectItem>
                  {categories.map((category) => (
                    <SelectItem key={category} value={category}>
                      {category}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select value={filterPlot} onValueChange={setFilterPlot}>
                <SelectTrigger>
                  <SelectValue placeholder={t("transactions.plot")} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">
                    {t("transactions.filterAll")} {t("transactions.plot")}
                  </SelectItem>
                  {plots.map((plot) => (
                    <SelectItem key={plot} value={plot}>
                      {plot}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Button
                variant="outline"
                onClick={() => {
                  setSearchTerm("")
                  setFilterType("all")
                  setFilterCategory("all")
                  setFilterPlot("all")
                }}
                className="w-full"
              >
                Clear {t("common.filter")}s
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Transactions List */}
        <Card className="bg-white shadow-md">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>
                {t("transactions.title")} ({filteredTransactions.length})
              </span>
              <Badge variant="outline" className="text-sm">
                Showing {filteredTransactions.length} of {transactions.length}
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {filteredTransactions.length === 0 ? (
                <div className="text-center py-12">
                  <div className="text-gray-400 mb-4">
                    <Search className="w-12 h-12 mx-auto" />
                  </div>
                  {transactions.length === 0 ? (
                    <>
                      <p className="text-gray-500 text-lg mb-4">No transactions yet</p>
                      <Link href="/add-transaction">
                        <Button className="bg-green-600 hover:bg-green-700">
                          <Plus className="w-4 h-4 mr-2" />
                          Add Your First Transaction
                        </Button>
                      </Link>
                    </>
                  ) : (
                    <>
                      <p className="text-gray-500 text-lg">{t("common.noData")}</p>
                      <p className="text-gray-400">Try adjusting your search or filters</p>
                    </>
                  )}
                </div>
              ) : (
                filteredTransactions
                  .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
                  .map((transaction) => (
                    <div
                      key={transaction.id}
                      className="flex items-center justify-between p-4 border border-gray-100 rounded-lg hover:bg-gray-50 transition-colors"
                    >
                      <div className="flex items-center space-x-4 flex-1">
                        <div
                          className={`w-4 h-4 rounded-full ${
                            transaction.type === "income" ? "bg-green-500" : "bg-amber-500"
                          }`}
                        />

                        <div className="flex-1 min-w-0">
                          <div className="flex items-center space-x-3 mb-2">
                            <h3 className="font-semibold text-gray-900">
                              {transaction.subcategory || transaction.category}
                            </h3>
                            <Badge
                              variant="outline"
                              className={`text-xs ${categoryColors[transaction.category] || "bg-gray-100 text-gray-800"}`}
                            >
                              {transaction.category}
                            </Badge>
                          </div>

                          <div className="flex items-center space-x-4 text-sm text-gray-500">
                            <div className="flex items-center space-x-1">
                              <Calendar className="w-3 h-3" />
                              <span>{new Date(transaction.date).toLocaleDateString()}</span>
                            </div>
                            <div className="flex items-center space-x-1">
                              <MapPin className="w-3 h-3" />
                              <span>{transaction.plot}</span>
                            </div>
                          </div>

                          {transaction.notes && (
                            <p className="text-sm text-gray-600 mt-1 truncate">{transaction.notes}</p>
                          )}
                        </div>
                      </div>

                      <div className="text-right ml-4">
                        <div
                          className={`text-lg font-bold ${
                            transaction.type === "income" ? "text-green-600" : "text-amber-600"
                          }`}
                        >
                          {transaction.type === "income" ? "+" : "-"}
                          {t("common.currency")}
                          {transaction.amount.toLocaleString()}
                        </div>
                        <div className="flex space-x-2 mt-1">
                          <Button variant="ghost" size="sm" className="text-xs text-gray-500 hover:text-gray-700">
                            {t("common.edit")}
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="text-xs text-red-500 hover:text-red-700"
                            onClick={() => handleDeleteTransaction(transaction.id)}
                          >
                            <Trash2 className="w-3 h-3" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))
              )}
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
