"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { ArrowLeft, CalendarIcon, Save, Mic, CheckCircle } from "lucide-react"
import { format } from "date-fns"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { useLanguage } from "@/contexts/language-context"
import { storage } from "@/lib/storage"

export function TransactionForm() {
  const { t } = useLanguage()
  const router = useRouter()
  const [date, setDate] = useState<Date>(new Date())
  const [saving, setSaving] = useState(false)
  const [saved, setSaved] = useState(false)
  const [formData, setFormData] = useState({
    type: "",
    amount: "",
    category: "",
    subcategory: "",
    plot: "",
    paymentMethod: "",
    notes: "",
  })

  const categories = {
    income: ["Crop Sale", "Livestock", "Government Subsidy", "Other Income"],
    expense: ["Seeds", "Fertilizer", "Equipment", "Labor", "Utilities", "Transportation", "Other Expense"],
  }

  const farms = storage.getFarms()
  const paymentMethods = ["Cash", "Bank Transfer", "Check", "Digital Payment", "Credit"]

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!formData.type || !formData.amount || !formData.category || !formData.plot) {
      alert("Please fill in all required fields")
      return
    }

    setSaving(true)

    try {
      // Save transaction to localStorage
      const transaction = storage.saveTransaction({
        type: formData.type as "income" | "expense",
        amount: Number.parseFloat(formData.amount),
        category: formData.category,
        subcategory: formData.subcategory,
        plot: formData.plot,
        date: date.toISOString(),
        paymentMethod: formData.paymentMethod,
        notes: formData.notes,
      })

      setSaved(true)

      // Show success message briefly then redirect
      setTimeout(() => {
        router.push("/transactions")
      }, 1500)
    } catch (error) {
      console.error("Failed to save transaction:", error)
      alert("Failed to save transaction. Please try again.")
    } finally {
      setSaving(false)
    }
  }

  if (saved) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-amber-50 flex items-center justify-center">
        <Card className="bg-white shadow-lg max-w-md mx-auto">
          <CardContent className="p-8 text-center">
            <CheckCircle className="w-16 h-16 text-green-600 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-green-800 mb-2">Transaction Saved!</h2>
            <p className="text-gray-600">Your transaction has been saved successfully.</p>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-amber-50">
      {/* Header */}
      <header className="bg-white border-b border-green-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <Link href="/transactions">
                <Button variant="ghost" size="sm" className="text-green-700 hover:text-green-800">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  {t("transactions.title")}
                </Button>
              </Link>
              <h1 className="text-xl font-bold text-green-800">Add Transaction</h1>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <form onSubmit={handleSubmit}>
          <Card className="bg-white shadow-lg">
            <CardHeader>
              <CardTitle className="text-2xl text-green-800">New Transaction</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Transaction Type */}
              <div className="grid grid-cols-2 gap-4">
                <Button
                  type="button"
                  variant={formData.type === "income" ? "default" : "outline"}
                  className={`h-16 ${
                    formData.type === "income"
                      ? "bg-green-600 hover:bg-green-700"
                      : "border-green-600 text-green-700 hover:bg-green-50"
                  }`}
                  onClick={() => setFormData({ ...formData, type: "income", category: "", subcategory: "" })}
                >
                  {t("transactions.income")}
                </Button>
                <Button
                  type="button"
                  variant={formData.type === "expense" ? "default" : "outline"}
                  className={`h-16 ${
                    formData.type === "expense"
                      ? "bg-amber-600 hover:bg-amber-700"
                      : "border-amber-600 text-amber-700 hover:bg-amber-50"
                  }`}
                  onClick={() => setFormData({ ...formData, type: "expense", category: "", subcategory: "" })}
                >
                  {t("transactions.expense")}
                </Button>
              </div>

              {/* Amount */}
              <div className="space-y-2">
                <Label htmlFor="amount" className="text-lg font-semibold">
                  {t("transactions.amount")} *
                </Label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500 text-lg">
                    {t("common.currency")}
                  </span>
                  <Input
                    id="amount"
                    type="number"
                    placeholder="0"
                    value={formData.amount}
                    onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                    className="pl-8 h-12 text-lg"
                    required
                  />
                </div>
              </div>

              {/* Category */}
              {formData.type && (
                <div className="space-y-2">
                  <Label className="text-lg font-semibold">{t("transactions.category")} *</Label>
                  <Select
                    value={formData.category}
                    onValueChange={(value) => setFormData({ ...formData, category: value, subcategory: "" })}
                    required
                  >
                    <SelectTrigger className="h-12">
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories[formData.type as keyof typeof categories]?.map((category) => (
                        <SelectItem key={category} value={category}>
                          {category}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}

              {/* Plot/Farm */}
              <div className="space-y-2">
                <Label className="text-lg font-semibold">{t("transactions.plot")} *</Label>
                <Select
                  value={formData.plot}
                  onValueChange={(value) => setFormData({ ...formData, plot: value })}
                  required
                >
                  <SelectTrigger className="h-12">
                    <SelectValue placeholder="Select plot/farm" />
                  </SelectTrigger>
                  <SelectContent>
                    {farms.map((farm) => (
                      <SelectItem key={farm.id} value={farm.name}>
                        {farm.name} - {farm.cropType}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Date */}
              <div className="space-y-2">
                <Label className="text-lg font-semibold">{t("transactions.date")} *</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className="w-full h-12 justify-start text-left font-normal bg-transparent"
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {date ? format(date, "PPP") : <span>Pick a date</span>}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar mode="single" selected={date} onSelect={(date) => date && setDate(date)} initialFocus />
                  </PopoverContent>
                </Popover>
              </div>

              {/* Payment Method */}
              <div className="space-y-2">
                <Label className="text-lg font-semibold">Payment Method</Label>
                <Select
                  value={formData.paymentMethod}
                  onValueChange={(value) => setFormData({ ...formData, paymentMethod: value })}
                >
                  <SelectTrigger className="h-12">
                    <SelectValue placeholder="Select payment method" />
                  </SelectTrigger>
                  <SelectContent>
                    {paymentMethods.map((method) => (
                      <SelectItem key={method} value={method}>
                        {method}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Notes */}
              <div className="space-y-2">
                <Label htmlFor="notes" className="text-lg font-semibold flex items-center space-x-2">
                  <span>Notes</span>
                  <Button type="button" variant="ghost" size="sm" className="p-1">
                    <Mic className="w-4 h-4" />
                  </Button>
                </Label>
                <Textarea
                  id="notes"
                  placeholder="Add any additional notes..."
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  className="min-h-[100px]"
                />
              </div>

              {/* Action Buttons */}
              <div className="flex space-x-4 pt-6">
                <Button
                  type="submit"
                  className="flex-1 h-12 bg-green-600 hover:bg-green-700 text-white"
                  disabled={saving}
                >
                  <Save className="w-4 h-4 mr-2" />
                  {saving ? "Saving..." : `${t("common.save")} Transaction`}
                </Button>
                <Link href="/transactions" className="flex-1">
                  <Button variant="outline" className="w-full h-12 bg-transparent">
                    {t("common.cancel")}
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </form>
      </main>
    </div>
  )
}
