import { TransactionForm } from "@/components/transaction-form"

export default function AddTransactionPage() {
  return <TransactionForm />
}
