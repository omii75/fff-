import { openai } from "@ai-sdk/openai"
import { streamText } from "ai"

export async function POST(req: Request) {
  const { messages } = await req.json()

  const result = await streamText({
    model: openai("gpt-4o"),
    system: `You are a helpful farming finance assistant for a farming finance tracker app. 
    You help farmers with:
    - Financial planning and budgeting advice
    - Crop expense tracking and optimization
    - Income forecasting and analysis
    - Farm management best practices
    - Agricultural loan and investment guidance
    - Seasonal financial planning
    - Cost reduction strategies
    
    Keep responses concise, practical, and farmer-friendly. Use simple language and provide actionable advice.
    Focus on farming and agricultural finance topics.`,
    messages,
  })

  return result.toAIStreamResponse()
}
