import { SettingsSync } from "@/components/settings-sync"

export default function SettingsPage() {
  return <SettingsSync />
}
