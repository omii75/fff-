import { FarmsManagement } from "@/components/farms-management"

export default function FarmsPage() {
  return <FarmsManagement />
}
