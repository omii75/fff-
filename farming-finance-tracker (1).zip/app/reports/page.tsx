import { ReportsInsights } from "@/components/reports-insights"

export default function ReportsPage() {
  return <ReportsInsights />
}
