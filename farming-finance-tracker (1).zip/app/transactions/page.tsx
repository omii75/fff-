import { TransactionsList } from "@/components/transactions-list"

export default function TransactionsPage() {
  return <TransactionsList />
}
