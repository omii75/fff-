"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect } from "react"

export type Language = "en" | "hi" | "te" | "bn" | "ta" | "mr" | "gu" | "kn"

interface LanguageContextType {
  language: Language
  setLanguage: (lang: Language) => void
  t: (key: string) => string
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined)

export const useLanguage = () => {
  const context = useContext(LanguageContext)
  if (!context) {
    throw new Error("useLanguage must be used within a LanguageProvider")
  }
  return context
}

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<Language>("en")

  useEffect(() => {
    const savedLanguage = localStorage.getItem("farming-app-language") as Language
    if (savedLanguage) {
      setLanguage(savedLanguage)
    }
  }, [])

  const handleSetLanguage = (lang: Language) => {
    setLanguage(lang)
    localStorage.setItem("farming-app-language", lang)
  }

  const t = (key: string): string => {
    return translations[language]?.[key] || translations.en[key] || key
  }

  return (
    <LanguageContext.Provider value={{ language, setLanguage: handleSetLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  )
}

const translations: Record<Language, Record<string, string>> = {
  en: {
    // Navigation
    "nav.dashboard": "Dashboard",
    "nav.transactions": "Transactions",
    "nav.farms": "Farms",
    "nav.reports": "Reports",
    "nav.settings": "Settings",

    // Dashboard
    "dashboard.title": "Farm Finance Dashboard",
    "dashboard.totalIncome": "Total Income",
    "dashboard.totalExpenses": "Total Expenses",
    "dashboard.netProfit": "Net Profit",
    "dashboard.quickAdd": "Quick Add",
    "dashboard.addIncome": "Add Income",
    "dashboard.addExpense": "Add Expense",
    "dashboard.recentTransactions": "Recent Transactions",
    "dashboard.viewAll": "View All",
    "dashboard.incomeVsExpenses": "Income vs Expenses",
    "dashboard.categoryBreakdown": "Category Breakdown",
    "dashboard.offline": "Offline",
    "dashboard.online": "Online",
    "dashboard.syncPending": "Sync Pending",

    // Transactions
    "transactions.title": "All Transactions",
    "transactions.search": "Search transactions...",
    "transactions.filterAll": "All",
    "transactions.filterIncome": "Income",
    "transactions.filterExpense": "Expense",
    "transactions.category": "Category",
    "transactions.plot": "Plot",
    "transactions.amount": "Amount",
    "transactions.date": "Date",
    "transactions.type": "Type",
    "transactions.income": "Income",
    "transactions.expense": "Expense",
    "transactions.edit": "Edit",
    "transactions.delete": "Delete",

    // Categories
    "category.seeds": "Seeds",
    "category.fertilizer": "Fertilizer",
    "category.equipment": "Equipment",
    "category.labor": "Labor",
    "category.cropSales": "Crop Sales",
    "category.livestock": "Livestock",
    "category.other": "Other",

    // Common
    "common.save": "Save",
    "common.cancel": "Cancel",
    "common.edit": "Edit",
    "common.delete": "Delete",
    "common.add": "Add",
    "common.search": "Search",
    "common.filter": "Filter",
    "common.loading": "Loading...",
    "common.noData": "No data available",
    "common.currency": "₹",
  },
  hi: {
    // Navigation
    "nav.dashboard": "डैशबोर्ड",
    "nav.transactions": "लेन-देन",
    "nav.farms": "खेत",
    "nav.reports": "रिपोर्ट",
    "nav.settings": "सेटिंग्स",

    // Dashboard
    "dashboard.title": "कृषि वित्त डैशबोर्ड",
    "dashboard.totalIncome": "कुल आय",
    "dashboard.totalExpenses": "कुल खर्च",
    "dashboard.netProfit": "शुद्ध लाभ",
    "dashboard.quickAdd": "त्वरित जोड़ें",
    "dashboard.addIncome": "आय जोड़ें",
    "dashboard.addExpense": "खर्च जोड़ें",
    "dashboard.recentTransactions": "हाल के लेन-देन",
    "dashboard.viewAll": "सभी देखें",
    "dashboard.incomeVsExpenses": "आय बनाम खर्च",
    "dashboard.categoryBreakdown": "श्रेणी विभाजन",
    "dashboard.offline": "ऑफलाइन",
    "dashboard.online": "ऑनलाइन",
    "dashboard.syncPending": "सिंक लंबित",

    // Transactions
    "transactions.title": "सभी लेन-देन",
    "transactions.search": "लेन-देन खोजें...",
    "transactions.filterAll": "सभी",
    "transactions.filterIncome": "आय",
    "transactions.filterExpense": "खर्च",
    "transactions.category": "श्रेणी",
    "transactions.plot": "प्लॉट",
    "transactions.amount": "राशि",
    "transactions.date": "दिनांक",
    "transactions.type": "प्रकार",
    "transactions.income": "आय",
    "transactions.expense": "खर्च",
    "transactions.edit": "संपादित करें",
    "transactions.delete": "हटाएं",

    // Categories
    "category.seeds": "बीज",
    "category.fertilizer": "उर्वरक",
    "category.equipment": "उपकरण",
    "category.labor": "श्रम",
    "category.cropSales": "फसल बिक्री",
    "category.livestock": "पशुधन",
    "category.other": "अन्य",

    // Common
    "common.save": "सहेजें",
    "common.cancel": "रद्द करें",
    "common.edit": "संपादित करें",
    "common.delete": "हटाएं",
    "common.add": "जोड़ें",
    "common.search": "खोजें",
    "common.filter": "फिल्टर",
    "common.loading": "लोड हो रहा है...",
    "common.noData": "कोई डेटा उपलब्ध नहीं",
    "common.currency": "₹",
  },
  te: {
    // Navigation
    "nav.dashboard": "డాష్‌బోర్డ్",
    "nav.transactions": "లావాదేవీలు",
    "nav.farms": "వ్యవసాయ క్షేత్రాలు",
    "nav.reports": "నివేదికలు",
    "nav.settings": "సెట్టింగులు",

    // Dashboard
    "dashboard.title": "వ్యవసాయ ఆర్థిక డాష్‌బోర్డ్",
    "dashboard.totalIncome": "మొత్తం ఆదాయం",
    "dashboard.totalExpenses": "మొత్తం ఖర్చులు",
    "dashboard.netProfit": "నికర లాభం",
    "dashboard.quickAdd": "త్వరిత జోడింపు",
    "dashboard.addIncome": "ఆదాయం జోడించండి",
    "dashboard.addExpense": "ఖర్చు జోడించండి",
    "dashboard.recentTransactions": "ఇటీవలి లావాదేవీలు",
    "dashboard.viewAll": "అన్నీ చూడండి",
    "dashboard.incomeVsExpenses": "ఆదాయం వర్సెస్ ఖర్చులు",
    "dashboard.categoryBreakdown": "వర్గ విభజన",
    "dashboard.offline": "ఆఫ్‌లైన్",
    "dashboard.online": "ఆన్‌లైన్",
    "dashboard.syncPending": "సింక్ పెండింగ్",

    // Transactions
    "transactions.title": "అన్ని లావాదేవీలు",
    "transactions.search": "లావాదేవీలను వెతకండి...",
    "transactions.filterAll": "అన్నీ",
    "transactions.filterIncome": "ఆదాయం",
    "transactions.filterExpense": "ఖర్చు",
    "transactions.category": "వర్గం",
    "transactions.plot": "ప్లాట్",
    "transactions.amount": "మొత్తం",
    "transactions.date": "తేదీ",
    "transactions.type": "రకం",
    "transactions.income": "ఆదాయం",
    "transactions.expense": "ఖర్చు",
    "transactions.edit": "సవరించండి",
    "transactions.delete": "తొలగించండి",

    // Categories
    "category.seeds": "విత్తనాలు",
    "category.fertilizer": "ఎరువులు",
    "category.equipment": "పరికరాలు",
    "category.labor": "కార్మికులు",
    "category.cropSales": "పంట అమ్మకాలు",
    "category.livestock": "పశువులు",
    "category.other": "ఇతర",

    // Common
    "common.save": "సేవ్ చేయండి",
    "common.cancel": "రద్దు చేయండి",
    "common.edit": "సవరించండి",
    "common.delete": "తొలగించండి",
    "common.add": "జోడించండి",
    "common.search": "వెతకండి",
    "common.filter": "ఫిల్టర్",
    "common.loading": "లోడ్ అవుతోంది...",
    "common.noData": "డేటా అందుబాటులో లేదు",
    "common.currency": "₹",
  },
  bn: {
    // Navigation
    "nav.dashboard": "ড্যাশবোর্ড",
    "nav.transactions": "লেনদেন",
    "nav.farms": "খামার",
    "nav.reports": "রিপোর্ট",
    "nav.settings": "সেটিংস",

    // Dashboard
    "dashboard.title": "কৃষি অর্থ ড্যাশবোর্ড",
    "dashboard.totalIncome": "মোট আয়",
    "dashboard.totalExpenses": "মোট খরচ",
    "dashboard.netProfit": "নিট লাভ",
    "dashboard.quickAdd": "দ্রুত যোগ করুন",
    "dashboard.addIncome": "আয় যোগ করুন",
    "dashboard.addExpense": "খরচ যোগ করুন",
    "dashboard.recentTransactions": "সাম্প্রতিক লেনদেন",
    "dashboard.viewAll": "সব দেখুন",
    "dashboard.incomeVsExpenses": "আয় বনাম খরচ",
    "dashboard.categoryBreakdown": "বিভাগ ভাঙ্গন",
    "dashboard.offline": "অফলাইন",
    "dashboard.online": "অনলাইন",
    "dashboard.syncPending": "সিঙ্ক মুলতুবি",

    // Transactions
    "transactions.title": "সব লেনদেন",
    "transactions.search": "লেনদেন খুঁজুন...",
    "transactions.filterAll": "সব",
    "transactions.filterIncome": "আয়",
    "transactions.filterExpense": "খরচ",
    "transactions.category": "বিভাগ",
    "transactions.plot": "প্লট",
    "transactions.amount": "পরিমাণ",
    "transactions.date": "তারিখ",
    "transactions.type": "ধরন",
    "transactions.income": "আয়",
    "transactions.expense": "খরচ",
    "transactions.edit": "সম্পাদনা",
    "transactions.delete": "মুছুন",

    // Categories
    "category.seeds": "বীজ",
    "category.fertilizer": "সার",
    "category.equipment": "যন্ত্রপাতি",
    "category.labor": "শ্রম",
    "category.cropSales": "ফসল বিক্রয়",
    "category.livestock": "পশুসম্পদ",
    "category.other": "অন্যান্য",

    // Common
    "common.save": "সংরক্ষণ করুন",
    "common.cancel": "বাতিল করুন",
    "common.edit": "সম্পাদনা করুন",
    "common.delete": "মুছুন",
    "common.add": "যোগ করুন",
    "common.search": "খুঁজুন",
    "common.filter": "ফিল্টার",
    "common.loading": "লোড হচ্ছে...",
    "common.noData": "কোন ডেটা নেই",
    "common.currency": "₹",
  },
  ta: {
    // Navigation
    "nav.dashboard": "டாஷ்போர்டு",
    "nav.transactions": "பரிவர்த்தனைகள்",
    "nav.farms": "பண்ணைகள்",
    "nav.reports": "அறிக்கைகள்",
    "nav.settings": "அமைப்புகள்",

    // Dashboard
    "dashboard.title": "விவசாய நிதி டாஷ்போர்டு",
    "dashboard.totalIncome": "மொத்த வருமானம்",
    "dashboard.totalExpenses": "மொத்த செலவுகள்",
    "dashboard.netProfit": "நிகர லாபம்",
    "dashboard.quickAdd": "விரைவு சேர்க்கை",
    "dashboard.addIncome": "வருமானம் சேர்க்கவும்",
    "dashboard.addExpense": "செலவு சேர்க்கவும்",
    "dashboard.recentTransactions": "சமீபத்திய பரிவர்த்தனைகள்",
    "dashboard.viewAll": "அனைத்தையும் பார்க்கவும்",
    "dashboard.incomeVsExpenses": "வருமானம் vs செலவுகள்",
    "dashboard.categoryBreakdown": "வகை பிரிவு",
    "dashboard.offline": "ஆஃப்லைன்",
    "dashboard.online": "ஆன்லைன்",
    "dashboard.syncPending": "ஒத்திசைவு நிலுவையில்",

    // Common
    "common.currency": "₹",
  },
  mr: {
    // Navigation
    "nav.dashboard": "डॅशबोर्ड",
    "nav.transactions": "व्यवहार",
    "nav.farms": "शेत",
    "nav.reports": "अहवाल",
    "nav.settings": "सेटिंग्ज",

    // Dashboard
    "dashboard.title": "शेती वित्त डॅशबोर्ड",
    "dashboard.totalIncome": "एकूण उत्पन्न",
    "dashboard.totalExpenses": "एकूण खर्च",
    "dashboard.netProfit": "निव्वळ नफा",
    "dashboard.quickAdd": "त्वरित जोडा",
    "dashboard.addIncome": "उत्पन्न जोडा",
    "dashboard.addExpense": "खर्च जोडा",

    // Common
    "common.currency": "₹",
  },
  gu: {
    // Navigation
    "nav.dashboard": "ડેશબોર્ડ",
    "nav.transactions": "વ્યવહારો",
    "nav.farms": "ખેતરો",
    "nav.reports": "રિપોર્ટ્સ",
    "nav.settings": "સેટિંગ્સ",

    // Dashboard
    "dashboard.title": "કૃષિ નાણા ડેશબોર્ડ",
    "dashboard.totalIncome": "કુલ આવક",
    "dashboard.totalExpenses": "કુલ ખર્ચ",
    "dashboard.netProfit": "ચોખ્ખો નફો",

    // Common
    "common.currency": "₹",
  },
  kn: {
    // Navigation
    "nav.dashboard": "ಡ್ಯಾಶ್‌ಬೋರ್ಡ್",
    "nav.transactions": "ವ್ಯವಹಾರಗಳು",
    "nav.farms": "ಫಾರ್ಮ್‌ಗಳು",
    "nav.reports": "ವರದಿಗಳು",
    "nav.settings": "ಸೆಟ್ಟಿಂಗ್‌ಗಳು",

    // Dashboard
    "dashboard.title": "ಕೃಷಿ ಹಣಕಾಸು ಡ್ಯಾಶ್‌ಬೋರ್ಡ್",
    "dashboard.totalIncome": "ಒಟ್ಟು ಆದಾಯ",
    "dashboard.totalExpenses": "ಒಟ್ಟು ವೆಚ್ಚಗಳು",
    "dashboard.netProfit": "ನಿವ್ವಳ ಲಾಭ",

    // Common
    "common.currency": "₹",
  },
}
