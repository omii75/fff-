export interface Transaction {
  id: string
  type: "income" | "expense"
  amount: number
  category: string
  subcategory?: string
  plot: string
  date: string
  paymentMethod?: string
  notes?: string
  createdAt: string
  updatedAt: string
}

export interface Farm {
  id: string
  name: string
  area: number
  location: string
  cropType?: string
  createdAt: string
}

class LocalStorage {
  private getItem<T>(key: string, defaultValue: T): T {
    if (typeof window === "undefined") return defaultValue
    try {
      const item = localStorage.getItem(key)
      return item ? JSON.parse(item) : defaultValue
    } catch {
      return defaultValue
    }
  }

  private setItem(key: string, value: any): void {
    if (typeof window === "undefined") return
    try {
      localStorage.setItem(key, JSON.stringify(value))
    } catch (error) {
      console.error("Failed to save to localStorage:", error)
    }
  }

  // Transactions
  getTransactions(): Transaction[] {
    return this.getItem("farming-transactions", [])
  }

  saveTransaction(transaction: Omit<Transaction, "id" | "createdAt" | "updatedAt">): Transaction {
    const transactions = this.getTransactions()
    const newTransaction: Transaction = {
      ...transaction,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }
    transactions.push(newTransaction)
    this.setItem("farming-transactions", transactions)
    return newTransaction
  }

  updateTransaction(id: string, updates: Partial<Transaction>): Transaction | null {
    const transactions = this.getTransactions()
    const index = transactions.findIndex((t) => t.id === id)
    if (index === -1) return null

    transactions[index] = {
      ...transactions[index],
      ...updates,
      updatedAt: new Date().toISOString(),
    }
    this.setItem("farming-transactions", transactions)
    return transactions[index]
  }

  deleteTransaction(id: string): boolean {
    const transactions = this.getTransactions()
    const filtered = transactions.filter((t) => t.id !== id)
    if (filtered.length === transactions.length) return false

    this.setItem("farming-transactions", filtered)
    return true
  }

  // Farms
  getFarms(): Farm[] {
    return this.getItem("farming-farms", [
      {
        id: "1",
        name: "Field A",
        area: 5,
        location: "North Plot",
        cropType: "Rice",
        createdAt: new Date().toISOString(),
      },
      {
        id: "2",
        name: "Field B",
        area: 3,
        location: "South Plot",
        cropType: "Wheat",
        createdAt: new Date().toISOString(),
      },
      {
        id: "3",
        name: "Field C",
        area: 2,
        location: "East Plot",
        cropType: "Vegetables",
        createdAt: new Date().toISOString(),
      },
    ])
  }

  saveFarm(farm: Omit<Farm, "id" | "createdAt">): Farm {
    const farms = this.getFarms()
    const newFarm: Farm = {
      ...farm,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
    }
    farms.push(newFarm)
    this.setItem("farming-farms", farms)
    return newFarm
  }

  // Settings
  getSettings() {
    return this.getItem("farming-settings", {
      autoSync: true,
      voiceInput: true,
      notifications: true,
      highContrast: false,
      lastSync: null,
    })
  }

  saveSettings(settings: any) {
    this.setItem("farming-settings", settings)
  }

  // Sync status
  updateLastSync() {
    const settings = this.getSettings()
    settings.lastSync = new Date().toISOString()
    this.saveSettings(settings)
  }
}

export const storage = new LocalStorage()
